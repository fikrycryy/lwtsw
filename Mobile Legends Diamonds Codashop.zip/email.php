<?php 

$emailku = "unchekfikry@gmail.com"; // Ganti pake email loe
?>